from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required
from django.http import Http404

# 1. 같은 앱(account) 내 views 폴더와 나란히 있는 models.py에서 Account 가져오기
from ..models import Account 
# 2. 다른 앱(shop)의 models.py에서 Cart 모델 가져오기
from shop.models import Cart 
from account.utils.common import get_default_account


@login_required
def charge_balance(request):
    if request.method == "POST":
        amount = request.POST.get("amount")
        # base.html의 모달 폼에서 보낸 현재 페이지 주소 (request.path)
        next_url = request.POST.get("next")

        try:
            amount_int = int(amount)
        except (TypeError, ValueError):
            amount_int = 0

        if amount_int > 0:
            # 사용자의 기본 계좌 정보 가져오기
            account = get_default_account(request.user)
            if not account:
                raise Http404("계좌 정보가 없습니다.")
            
            # 잔액 충전 및 저장
            account.balance += amount_int
            account.save()

        # [리다이렉트 로직]
        # 1순위: 주문서 등 원래 있던 페이지(next_url)로 돌아가기
        if next_url:
            return redirect(next_url)
        
        # 2순위: next_url이 없다면 이전 페이지(Referer)로 돌아가기
        return redirect(request.META.get("HTTP_REFERER", "main"))

    # POST 요청이 아닐 경우 메인으로 이동
    return redirect("main")