from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required
from django.http import Http404
from django.utils import timezone  # ✅ 추가

# 1. 같은 앱(account) 내 views 폴더와 나란히 있는 models.py에서 Account 가져오기
from ..models import Account
# 2. 다른 앱(shop)의 models.py에서 Cart 모델 가져오기
from shop.models import Cart, Transaction  # ✅ Transaction 추가
from account.utils.common import get_default_account
from django.contrib import messages
from django.contrib.humanize.templatetags.humanize import intcomma 

@login_required
def charge_balance(request):
    if request.method == "POST":
        amount = request.POST.get("amount")
        account_id = request.POST.get("account_id")
        # base.html에서 보낸 쿼리스트링이 포함된 전체 주소
        next_url = request.POST.get("next")

        try:
            amount_int = int(amount)
        except (TypeError, ValueError):
            amount_int = 0

        if amount_int > 0:
            account = Account.objects.filter(id=account_id, user=request.user).first()
            if not account:
                messages.warning(request, "충전할 계좌를 선택해주세요.")
                return redirect(request.META.get("HTTP_REFERER", "/"))

            # 계좌 잔액 증가
            account.balance += amount_int
            account.save()

            # 거래 내역 기록
            Transaction.objects.create(
                user=request.user,
                account=account,
                tx_type=Transaction.IN,
                amount=amount_int,
                occurred_at=timezone.now(),
                product_name="계좌 충전",
                merchant="내 지갑",
                memo=f"{account.bank.name} 충전 완료"
            )
            messages.success(request, f"{intcomma(amount_int)}원이 성공적으로 충전되었습니다!")

        # [리다이렉트 핵심] 
        # 1. 결제 정보가 포함된 next_url이 있다면 최우선 이동
        if next_url and next_url != "":
            return redirect(next_url.split("#")[0])
        return redirect(request.META.get("HTTP_REFERER", "/"))
    # POST 요청이 아닐 경우 루트 페이지로 이동
    return redirect("/")
